package Modul;

public class TesterAddLast {
    public static void main(String[] args) {

        MyLinkedList myLL = new MyLinkedList();
        myLL.addLast(5);
        myLL.addLast(2);
        myLL.addLast(3);
        myLL.printAllInfo();

       

       
       

    }

}
